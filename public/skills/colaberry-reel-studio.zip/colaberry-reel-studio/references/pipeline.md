# Colaberry Reel Pipeline — Technical Reference

Copy-paste templates and math for every phase. All heavy work runs in the
Higgsfield sandbox (`Higgsfield:sandbox_exec`) — the only environment that can
reach the media CDN.

## Contents
1. Sandbox survival doctrine
2. Packing math (variable-length scenes)
3. Audio generation & per-scene track assembly
4. Video generation call shape
5. Collect & validate
6. Assembly (mega-filtergraph) — Stage A
7. Captions — Stage B
8. Upscale, logo, cover
9. Troubleshooting table (battle log)

---

## 1. Sandbox survival doctrine

- `sandbox_exec` hard cap: `timeout_seconds <= 120`. The sandbox RECYCLES
  unpredictably between calls (sometimes within seconds of idling); assume
  all filesystem state can vanish at any inter-call gap.
- Therefore: every call is **self-contained** (recreate all inputs inside it)
  and **ends with its artifact PUT to cloud** (presigned URL from
  `media_upload`, then `media_confirm`). Confirmed media serves publicly at
  `https://upload.higgsfield.ai/<user_prefix>/<media_id>.<ext>`.
- Long work pattern: `nohup ./run.sh > log 2>&1 & sleep 100-108; tail log`
  inside ONE call. If unfinished, immediate follow-up `sleep 95; grep ... log`
  keepalives — each inter-call gap is a recycle risk, so minimize their count.
- Every ffmpeg invocation gets `-nostdin`. Every `while read` loop reads via
  `read -u 9 ... 9< file` (never bare stdin — subprocesses can eat it).
- Command length: keep each sandbox_exec under ~16,000 chars. Base64 payloads
  (logo = 10,920 chars) fit alongside a compact runner.
- Presigned PUT URLs: nominally 24h, but the embedded STS token can die in
  ~3-4h (returns 400). Mint slots (`media_upload`) close to use; on 400, mint
  a fresh slot and re-PUT.
- Local (non-Higgsfield) execution environments usually CANNOT reach the
  Higgsfield CDN — do all media work in the Higgsfield sandbox.

## 2. Packing math

Inputs: ordered dialogue lines with speaker + measured (or estimated at
~3.05 words/sec) durations d_i. Gaps: 0.35s between lines inside a scene,
0.9s before a narrator CTA line, 0.5s scene lead-in (0.85s if the scene opens
with an extra beat gap).

Scene speech extent `E = sum(d_i) + 0.35*(k-1)` (+0.9 instead for CTA gap).
Choose window `W ∈ {6..10}` such that `W-1.4 <= E <= W`. If no W fits:
repack lines across adjacent scenes (never split a single take). A rapid
exchange that's too short for 10s becomes its own 6-7s scene; a long
monologue >10s splits at a sentence boundary into two takes in two scenes.
Total runtime = ΣW. Offsets: `off_1=0, off_i = off_{i-1} + W_{i-1}`.

Manifest (drives captions & any verification), one JSON:
`{"blocks":[{"n":i,"vo_line":"<exact concatenated text of the scene's
lines>", "location":"...", "shots":[5 short labels], "assets_used":[ids]}]}`
Location labels must not repeat >2x consecutively (use `-react`/`-alt`/
`-close` suffixes for recompositions).

## 3. Audio

One line = one take. `Higgsfield:generate_audio_batch`, max 12 requests/call
(429 rate-limit → wait ~30s, retry the remainder):

```json
{"index": n, "params": {"model": "seed_audio",
 "prompt": "[ <delivery bracket>, starts speaking immediately] [00:00-00:0N] <line>",
 "voice_id": "<preset uuid>", "voice_type": "preset"}}
```

Per-scene track assembly (48kHz mono s16le throughout):

```bash
# normalize each take
ffmpeg -nostdin -v error -y -i raw/lNN.wav -ar 48000 -ac 1 -c:a pcm_s16le n/lNN.wav
# silences
ffmpeg -nostdin -v error -y -f lavfi -i anullsrc=r=48000:cl=mono -t 0.35 -c:a pcm_s16le n/sil.wav   # inter-line
ffmpeg -nostdin -v error -y -f lavfi -i anullsrc=r=48000:cl=mono -t 0.9  -c:a pcm_s16le n/g9.wav    # pre-CTA
ffmpeg -nostdin -v error -y -f lavfi -i anullsrc=r=48000:cl=mono -t 0.5  -c:a pcm_s16le n/lead.wav  # scene lead
# concat (RE-ENCODE the concat output; list file paths absolute)
mk(){ o=$1; shift; :> /tmp/cl.txt; for f in "$@"; do echo "file '$PWD/n/$f'" >> /tmp/cl.txt; done;
  ffmpeg -nostdin -v error -y -f concat -safe 0 -i /tmp/cl.txt -c:a pcm_s16le "blk/$o"; }
mk voice01.wav lead.wav l01.wav
mk voice02.wav lead.wav l02.wav sil.wav l03.wav sil.wav l04.wav   # etc.
```

Never atempo/trim speech to hit pacing — fix packing instead. Measure each
track with ffprobe; extent `E = dur - lead` (subtract any extra leading sil).

## 4. Video

`Higgsfield:generate_video_batch`, one request per scene:
`model gemini_omni, resolution 720p, aspect_ratio 9:16, duration 10`,
`medias: [{role:"image_references", value:"<asset id>"} ...]` (stage plate
first, then characters in on-screen prominence order, then props; max 7),
`prompt` = STYLE BLOCK + PALETTE LOCK + shot grammar + AUDIO + NEGATIVE
(see design-system.md). If submission fails with `Preset "..." was
recommended`, resubmit identical requests adding
`"declined_preset_id": "<id from the error>"` to each `params`.

## 5. Collect & validate

- `Higgsfield:jobs_wait` (max 12 jobs/call, `timeout_seconds <= 15`, repoll
  until `all_terminal`). The returned `result_url` values are the ONLY
  trusted source for filenames — never retype UUIDs from memory (transcription
  errors are the historical #1 time sink; unknown ids return `lookup_failed`
  per-job without breaking the batch, so probing candidate ids is safe).
- Before assembly, validate every audio+clip URL:
  `curl -s -o /dev/null -w '%{http_code}' -r 0-0 "$URL"` → require 200/206;
  abort loudly with the offending index otherwise.

## 6. Assembly — Stage A (one self-contained call)

Build final master WITHOUT captions in a single ffmpeg mega-graph, then PUT.
Speech centering per scene i: `start_i = max(0,(W_i - E_i)/2)`;
`delay_i = start_i - lead_i` → if `delay_i >= 0` use
`adelay=<ms>:all=1`, else `atrim=start=<-delay>,asetpts=PTS-STARTPTS`
(trims lead silence only — speech untouched). Scene SFX ducked to 0.12.

Python builds the graph (9-scene example; generalize N):

```python
fc=[]; amaps=[]
for i in range(N):
    w=W[i]; e=E[i]; start=max(0.0,(w-e)/2); d=round(start-LEAD[i],3)
    fc.append(f"[{i}:v]trim=0:{w},setpts=PTS-STARTPTS,scale=720:1280:force_original_aspect_ratio=decrease,pad=720:1280:(ow-iw)/2:(oh-ih)/2:black,fps=24,format=yuv420p,setsar=1[v{i}]")
    fc.append(f"[{N+i}:a]adelay={int(d*1000)}:all=1[vo{i}]" if d>=0 else f"[{N+i}:a]atrim=start={-d},asetpts=PTS-STARTPTS[vo{i}]")
    fc.append(f"[{i}:a]volume=0.12[sf{i}]")
    fc.append(f"[sf{i}][vo{i}]amix=inputs=2:duration=first:normalize=0,atrim=0:{w},asetpts=PTS-STARTPTS[a{i}]")
    amaps.append(f"[v{i}][a{i}]")
fc.append("".join(amaps)+f"concat=n={N}:v=1:a=1[vc][ac]")
fc.append("[ac]loudnorm=I=-16:TP=-1.5:LRA=11,aformat=sample_rates=44100:channel_layouts=stereo[af]")
# inputs: N clips then N voice tracks; encode libx264 crf18 veryfast +faststart, aac 192k
```

Also emit the caption sidecar `merged.json`:
`{"blocks":N,"per_block":[{"n":i+1,"clip":"cI.mp4","voice":"voice0I.wav",
"clip_s":W_i,"speech_s":E_i,"speech_abs_s":off_i+start_i,
"lead_silence_s":LEAD_i,"internal_pauses":0,"freeze_head":false,
"freeze_tail":false}]}`
Caption time math downstream: `t_final = speech_abs_s + (t_word - lead_silence_s)`.

End of call: PUT master → out of band `media_confirm`.

## 7. Captions — Stage B (second self-contained call)

New sandbox: curl the confirmed master from upload.higgsfield.ai, rebuild the
per-scene voice tracks (Section 3 — deterministic, ~25s), regenerate
merged.json (same constants), then:

```bash
S=$HF_WORKFLOWS/faceless-channel-video/scripts
bash $S/subtitles/fetch_fonts.sh
python3 $S/subtitles/audio_to_captions.py final.mp4 --srt final.srt \
  --per-block merged.json --voice-dir blk --language en --script manifest.json
bash $S/subtitles/burn_caps_clean.sh --in final.mp4 --srt final.srt --out final_s.mp4
mv -f final_s.mp4 final.mp4
# gate: |video_dur - audio_dur| <= 0.25 (ffprobe per stream)
```

Then PUT → confirm. First run downloads a small whisper model + fonts
(~60-90s); pre-warm at call start with
`python3 -c "from faster_whisper import WhisperModel as W; W('tiny',device='cpu',compute_type='int8')" &`.
Print `tail final.srt` — the CTA cue timing feeds the logo T.

Alternative (when the packaged workflow fits): the packaged
`finish_video.sh` supports `--no-verify-audio` and, with a 2-line patch,
forwards `--clip-seconds` to `assemble_final.sh` (whose speech band is
`CLIP-1.4..CLIP`) — usable per-scene-group when uniform windows apply. The
mega-graph route above is faster and recycle-proof; the packaged route adds
its own transcript verification (`verify_takes.py`, similarity >= ~0.9).

## 8. Upscale, logo, cover

- Upscale: `Higgsfield:upscale_video` with params NESTED:
  `{"params":{"provider":"topaz","video_id":"<confirmed media id>",
  "resolution":"1080p","aspect_ratio":"auto"}}`. Poll `jobs_wait` (queue can
  sit 5-10 min).
- Logo: one call — inline the `.b64` asset (heredoc), decode, curl the 1080p
  result_url, apply the overlay recipe from design-system.md with
  `T = off_CTA_scene + start_CTA_scene + (time of CTA line within track)`,
  cross-check against the SRT tail (logo should land as the CTA line begins),
  encode, PUT → confirm.
- Cover: `ffmpeg -ss <total-0.5> -frames:v 1 -q:v 2` from the final, PUT to
  an image slot (`content_type image/jpeg`) → confirm.

## 9. Troubleshooting (battle log — check here FIRST)

| Symptom | Cause | Fix |
|---|---|---|
| `Preset "..." was recommended instead of submitting` | preset interceptor | resubmit with `declined_preset_id` from the error |
| audio batch 429 `rate_limit_reached` | >12/min | split batches, wait ~30s, retry remainder |
| `No approval received` on a tool | per-tool Allow gate | ask user to click Allow, retry same call |
| verify/captions transcribe near-empty ("you…") on good audio | stdin-eaten loop corrupted downloads | `-nostdin` on ffmpeg + `read -u 9 ... 9<` on loops; re-run |
| `voice N carries X s of speech; required 8.6-10.0` | fixed 10s window vs short dialogue | variable windows (Section 2); never pad/atempo speech |
| whole-run sandbox death mid-marathon | recycle + 120s cap | self-contained calls + cloud checkpoints (Sections 1,6,7) |
| PUT returns 400 on an older presigned URL | STS token expired (~3-4h) | mint fresh `media_upload` slot, re-PUT |
| retyped UUID/filename 403s | hex transcription drift | only use `jobs_wait` result_urls; ranged-GET validate all inputs |
| concat demuxer oddities | header/params mismatch | normalize all wavs to 48k mono s16le; re-encode concat output |
| fresh voice take longer than expected breaks centering | regenerated line length varies | measure, recompute E/W; negative delay path trims lead only |
| `jobs_wait` >12 items | API cap | chunk into <=12-job calls |
| cover/frame URL token dead next day | STS again | re-extract from the still-live final and PUT to a fresh slot |
