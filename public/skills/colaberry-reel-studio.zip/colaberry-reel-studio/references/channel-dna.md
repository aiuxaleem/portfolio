# Channel DNA — Reusable Asset Registry (fill in for your account)

Asset IDs belong to the Higgsfield account that generated them, so this public
edition ships the registry empty. On your first reel, generate the style key,
characters, locations and props (prompt patterns in design-system.md), then
write their IDs here. Every later reel reuses them for character, location and
prop consistency; regenerate only when a lookup fails.

## Style key
- Editorial Motion Graphics style reference image: `<your style key id>`
  (attach as a media ref when generating any NEW character/location/prop).

## Characters
| Asset | ID | Casting descriptors (for regeneration) |
|---|---|---|
| char-manager | `<id>` | THE MANAGER — woman, blazer, short hair, composed authoritative posture |
| char-michael | `<id>` | MICHAEL — senior office professional man ~50s, glasses, sweater vest, slightly weary experienced presence |
| char-ethan | `<id>` | ETHAN — young Black office professional man mid-20s, tidy short natural hair, casual button-up with rolled sleeves, energetic lean-forward posture |

## Locations (stage plates)
| Asset | ID | Contents |
|---|---|---|
| loc-meeting | `<id>` | cream field, red disc, conference table, project-plan cards |
| loc-meeting-alt | `<id>` | easel with dot-matrix chart, table edge |
| loc-hallway | `<id>` | newsprint strip, door frames, torn-edge photo frame |
| loc-hallway-alt | `<id>` | tall window frame, low bench, taped note card |
| loc-learning | `<id>` | graph-grid field, rising dot stair, timeline ribbon, red arrow |
| loc-desk | `<id>` | home desk, big cherry red disc, cream field |

## Props
| Asset | ID | Role |
|---|---|---|
| prop-laptop | `<id>` | THE CHERRY RED LAPTOP — the single color-popped hero + narrative through-line |
| prop-hand | `<id>` | giant monochrome hand cutout (payoff scenes) |
| prop-annotation | `<id>` | annotation pack: pinned cards, red marker strokes |

## Voices (seed_audio presets)
| Voice | ID | Cast to |
|---|---|---|
| Roxie | `f6448975-768e-4327-b932-1b7c973d58e9` | Manager |
| Callum | `858499d9-fef5-40e1-bc29-b4dc661dc283` | Michael |
| Cillian | `d8ba9f14-8a24-44db-932b-99e16c45bd32` | Ethan |
| Arthur | `30fc8796-ceb6-4a66-b3a7-4a145ef7f346` | Narrator/CTA |

(Higgsfield preset voices; check they are still offered in your account.)

## Video-generation constants
- model `gemini_omni`, 720p, 9:16, duration 10
- if the preset interceptor fires, read `declined_preset_id` from the error and resubmit

## Shipped reels (your reference outputs)
- Add the links of your finished reels here for later comparison.
