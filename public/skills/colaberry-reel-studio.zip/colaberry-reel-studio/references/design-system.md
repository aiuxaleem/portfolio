# Colaberry Reel Design System

The locked visual identity. Every image and video prompt is built from these
blocks verbatim — style drift is the #1 quality killer.

## Brand constants

- Accent: cherry red `#FB2832` — exactly ONE red accent family per video
  (disc, marker strokes, one color-popped hero object). Everything else is
  monochrome halftone on warm cream paper.
- Aspect: 9:16 (720p generation → Topaz 1080p).
- Music: none by default (voice + paper SFX only).
- Captions: "clean" style, white, bottom-third (pipeline's burn_caps_clean).
- Logo: transparent WebP 700x164 (`assets/logo.webp`, yours),
  slides in with soft shadow during the CTA line only.

## STYLE BLOCK (prepend to every image & video prompt, verbatim)

```
Style: flat editorial documentary collage on a warm cream paper stage with
subtle fiber grain: monochrome halftone archival photo cutouts with rough
white keylines and a slightly offset cherry red stroke behind each cutout,
one single cherry red accent color per video — a large flat cherry red disc
behind the main subject and exactly one color-popped hero element among the
monochrome — torn paper edges and tape strips, soft paper drop shadows,
hand-drawn cherry red marker circles, arrows and underline strokes (abstract
strokes only, never letters), abstract unlabeled data shapes and flat
stylized maps, subtle print misregistration on inked elements, snappy
staggered spring motion with slight overshoot, non-photorealistic
illustrated collage, never live-action
```

For VIDEO prompts append: `; snappy motion-graphics collage animation,
staggered spring entrances with slight overshoot — the visual style is
EXACTLY as in the reference images, same rendering, same surface treatment.`

## PALETTE LOCK (video prompts, after the style block)

```
PALETTE LOCK: use ONLY the colors and the background treatment of the
reference images (warm cream paper base, monochrome halftone cutouts, ONE
cherry red accent — disc, strokes, one popped element). Do NOT introduce any
new or foreign colors, no colored, gradient or painted backgrounds that are
not in the references, no recoloring of characters or objects.
```

## NEGATIVE BLOCK (video prompts, always last)

```
NEGATIVE: opening on a reference image, a sheet or swatch or a static first
frame, leading freeze, dissolves or fades, NEW or foreign colors, colored or
gradient or painted background not in the references, recolored characters,
style drift, extra people, cloned characters, characters talking, lip-sync,
on-screen text, captions, photorealism, 3D render, readable text, letters,
words, numbers, live-action footage, photographic realism, full-color scene,
foreign accent colors, watermark.
```

## Shot grammar (every scene)

A scene = ONE gemini_omni generation, 10.0s, FIVE hard cuts at 2/4/6/8s:

```
A single 10-second scene of FIVE hard-cut shots. Do NOT open the video on any
reference image or show a sheet or swatch — stage everything fresh, matching
characters, room, colors and background to their references. Characters only
emote and gesture, they do NOT talk. Motion starts on frame 1 (no opening
freeze). [If not the first scene in a location: "Do NOT open on a wide
establishing shot — this scene opens close."]
REFERENCES (look, identity, palette): @Image1 = <stage plate>. @Image2 =
<CHARACTER (short casting descriptor)>. ... (max 7 refs)
SHOT 1 — 0.0s to 2.0s — <FRAMING>, <camera>: <one clear action; one shot per
scene is "the impact beat">.
HARD CUT.
... (shots 2-5; SHOT 5 always "gentle drift ... eases into a settled, still
micro-moving final frame")
Five hard-cut shots at 2.0s, 4.0s, 6.0s and 8.0s, no dissolves, no fades.
Snappy motion-graphics collage animation, staggered spring entrances with
slight overshoot, continuous motion within each shot, never freezes.
AUDIO: <3-4 diegetic paper/foley cues>, low <room>-air bed — no voice, no
narration, no music.
```

Rules of thumb: alternate WIDE/CU rhythm; the color-popped hero object (the
cherry red laptop) appears in nearly every scene and carries the through-line;
red marker strokes are abstract only (never letters — burned captions carry
all text); max 2 consecutive scenes on the same stage plate (use the -alt
plate or a tighter recomposition).

## Character prompt pattern (seedream_v5_pro, 2:3, 2k, style-key ref attached)

```
Full-body character centered on a plain flat solid-color background, in THIS
EXACT style: <STYLE BLOCK>. Character: <NAME> — a monochrome halftone cutout
of <casting descriptors: age, ethnicity if specified, gender, wardrobe,
hair>, <posture/energy>, rough white keyline and slightly offset cherry red
stroke around the cutout, deadpan neutral standing pose, readable distinctive
silhouette. No text, no watermark.
```

Recasting = change ONLY the casting descriptors; keep wardrobe, posture,
energy, and every style word identical.

## Default cast & voice palette

Fill-in defaults when the user's script doesn't specify casting. Always
editable; explicit user casting wins.

| Role                | Default casting                         | Voice preset (seed_audio)                  | Delivery bracket base |
|---------------------|------------------------------------------|--------------------------------------------|-----------------------|
| Manager / team lead | white woman, blazer, short hair          | Roxie `f6448975-768e-4327-b932-1b7c973d58e9` | warm direct team-lead voice, American accent |
| Senior professional | white man ~50s, glasses, sweater vest    | Callum `858499d9-fef5-40e1-bc29-b4dc661dc283` | weary honest senior professional, American accent |
| Junior professional | young Black man, rolled-sleeve button-up | Cillian `d8ba9f14-8a24-44db-932b-99e16c45bd32` | confident eager young professional, American accent |
| Narrator (CTA)      | voice only                               | Arthur `30fc8796-ceb6-4a66-b3a7-4a145ef7f346` | assured motivational ad narrator, American accent |

All voices default to American-accent English. Audio prompt format:

```
[ <delivery bracket>, <emotion for this line>, starts speaking immediately] [00:00-00:0N] <exact line text>
```

where N ≈ ceil(words / 3) seconds. One take per line, per speaker.

## Caption style

Generated by the pipeline (`audio_to_captions.py` + `burn_caps_clean.sh`) —
never hand-draw captions. Fonts fetched by `fetch_fonts.sh` (Anton, Patrick
Hand, Permanent Marker, Caveat). "clean" = white bottom-third; "paper"/"bold"
variants exist but Colaberry ships clean.

## Logo reveal recipe

Composite the transparent WebP over the finished master during the CTA only.
T = timeline second when the CTA voice line begins (compute from packing:
scene offset + speech start; verify against the burned SRT tail).

ffmpeg filter (two-layer soft shadow + slide-settle from above):

```
[1:v]format=rgba,pad=iw+100:ih+100:50:50:color=black@0,split=3[lg][s1][s2];
[s1]colorchannelmixer=rr=0:gg=0:bb=0:aa=0.5,gblur=sigma=3[t1];
[s2]colorchannelmixer=rr=0:gg=0:bb=0:aa=0.35,gblur=sigma=11[t2];
[0:v][t2]overlay=x=(W-w)/2+10:y='164+240*exp(-10*(t-T))':enable='gte(t,T)'[va];
[va][t1]overlay=x=(W-w)/2+4:y='156+240*exp(-10*(t-T))':enable='gte(t,T)'[vb];
[vb][lg]overlay=x=(W-w)/2:y='150+240*exp(-10*(t-T))':enable='gte(t,T)'[vout]
```

Encode: `-map "[vout]" -map 0:a -c:v libx264 -crf 18 -preset veryfast
-pix_fmt yuv420p -movflags +faststart -c:a copy`. The logo lands ~150px from
the top — clear of the caption safe area. Asset is small enough (10,920 b64
chars) to inline in one sandbox call; the `.b64` file ships with this skill.
