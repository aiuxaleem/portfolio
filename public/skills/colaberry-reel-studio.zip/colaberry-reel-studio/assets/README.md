# Your logo

Put your transparent logo here as `logo.webp` (about 700x164) and its base64 text as `logo.webp.b64`
(`base64 -w0 logo.webp > logo.webp.b64`). The Brand phase inlines the base64 in one sandbox call.
The public edition of this skill ships without a logo.
