// Print [left, top, width, height] of selectors relative to the board, plus each element's content bottom.
// Usage: node scripts/measure.js /abs/path/board.html ".head,.hero,.strip,.foot,.hero svg"
const { chromium } = require('playwright');
(async () => {
  const [src, list = '.head,.hero,.strip,.foot,.hero svg', root = '.board'] = process.argv.slice(2);
  const b = await chromium.launch({ args: ['--no-sandbox'] });
  const p = await b.newPage({ viewport: { width: 1080, height: 1350 } });
  await p.goto('file://' + src); await p.evaluate(() => document.fonts.ready); await p.waitForTimeout(300);
  const r = await p.evaluate(({ list, root }) => {
    const bd = document.querySelector(root).getBoundingClientRect(); const out = {};
    list.split(',').forEach(s => { const e = document.querySelector(s.trim()); if (!e) { out[s] = null; return; }
      const r = e.getBoundingClientRect(); const last = e.lastElementChild ? e.lastElementChild.getBoundingClientRect() : r;
      out[s.trim()] = { box: [Math.round(r.left - bd.left), Math.round(r.top - bd.top), Math.round(r.width), Math.round(r.height)], contentBottom: Math.round(last.bottom - bd.top) }; });
    return out;
  }, { list, root });
  console.log(JSON.stringify(r, null, 1)); await b.close();
})();
