// Render a board HTML to PNG at 2x and report clipped or overflowing elements.
// Usage: node scripts/render.js /abs/path/board.html /abs/path/board.png [selector=.board] [width=1080] [height=1350]
const { chromium } = require('playwright');
(async () => {
  const [src, out, sel = '.board', w = '1080', h = '1350'] = process.argv.slice(2);
  const browser = await chromium.launch({ args: ['--no-sandbox'] });
  const page = await browser.newPage({ viewport: { width: +w, height: +h }, deviceScaleFactor: 2 });
  page.on('console', m => { if (m.type() === 'error') console.log('console:', m.text()); });
  page.on('requestfailed', r => console.log('failed:', r.url()));
  await page.goto('file://' + src, { waitUntil: 'load' });
  await page.evaluate(() => document.fonts.ready);
  await page.waitForTimeout(400);
  const info = await page.evaluate((sel) => {
    const fonts = [...document.fonts].map(f => f.family + ' ' + f.status);
    const root = document.querySelector(sel);
    const b = root.getBoundingClientRect();
    const bad = [];
    root.querySelectorAll('*').forEach(el => {
      const cs = getComputedStyle(el);
      if (el.scrollWidth > el.clientWidth + 1 && cs.overflow !== 'visible') bad.push('clipW ' + (el.className || el.tagName) + ' ' + el.scrollWidth + '>' + el.clientWidth);
      if (el.scrollHeight > el.clientHeight + 1 && cs.overflow !== 'visible' && el.clientHeight > 0) bad.push('clipH ' + (el.className || el.tagName) + ' ' + el.scrollHeight + '>' + el.clientHeight);
      const r = el.getBoundingClientRect();
      if (r.width > 0 && (r.right > b.right + 1 || r.bottom > b.bottom + 1)) bad.push('outside ' + (el.className || el.tagName) + ' ' + Math.round(r.right) + ',' + Math.round(r.bottom));
    });
    return { fonts, box: [b.width, b.height], bad: bad.slice(0, 20) };
  }, sel);
  console.log(JSON.stringify(info));
  await page.locator(sel).screenshot({ path: out, type: 'png' });
  await browser.close();
})();
