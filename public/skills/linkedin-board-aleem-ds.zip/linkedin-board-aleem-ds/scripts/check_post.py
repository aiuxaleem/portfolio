#!/usr/bin/env python3
"""Check a LinkedIn post file: length, em/en dashes, U+2800 spacers, first-line rule, closing question, hashtags.
Usage: python3 scripts/check_post.py work/<name>-post.txt   (also trims trailing newlines in place)"""
import re, sys
p = sys.argv[1]
t = open(p, encoding='utf-8').read().rstrip('\n')
open(p, 'w', encoding='utf-8').write(t)
lines = [l for l in t.split('\n') if l.strip() and l.strip() != '⠀']
problems = []
if len(t) > 2960: problems.append(f'length {len(t)} > 2960 (LinkedIn limit 3000, keep 40 spare)')
if '—' in t or '–' in t: problems.append('em or en dash present')
if re.search(r'[\U0001F300-\U0001FAFF☀-➿]', t): problems.append('emoji present')
first = lines[0]
if re.match(r'^\s*\d', first): problems.append('first line starts with a number')
if first.strip().endswith('?'): problems.append('first line is a question')
tags = re.findall(r'#\w+', lines[-1])
if not (2 <= len(tags) <= 3): problems.append(f'last line has {len(tags)} hashtags, want 2 or 3')
body = [l for l in lines[:-1]]
if not body or not body[-1].strip().endswith('?'): problems.append('line before the hashtags is not a question')
if re.search(r'https?://|in the comments|first comment', t, re.I): problems.append('link or "in the comments" present')
blank = t.count('\n\n')
if blank: problems.append(f'{blank} empty blank lines without U+2800 (LinkedIn will collapse them)')
print(f'{len(t)} chars, {t.count(chr(0x2800))} spacers, hashtags {tags}')
print('OK' if not problems else 'FIX:\n- ' + '\n- '.join(problems))
sys.exit(1 if problems else 0)
