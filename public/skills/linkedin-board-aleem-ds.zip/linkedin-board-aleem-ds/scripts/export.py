#!/usr/bin/env python3
"""Make the 1x preview, a JPG copy and 2x crops for inspection.
Usage: python3 scripts/export.py work/<name>.png [x0 y0 x1 y1 ...]  (crop boxes in 1x board pixels)"""
import sys
from PIL import Image
src = sys.argv[1]; base = src[:-4]
im = Image.open(src)
im.resize((im.width // 2, im.height // 2), Image.LANCZOS).save(base + '_preview.png')
im.convert('RGB').save(base + '.jpg', quality=92, subsampling=0)
boxes = list(map(int, sys.argv[2:]))
for i in range(0, len(boxes) - 3, 4):
    x0, y0, x1, y1 = boxes[i:i+4]
    im.crop((x0*2, y0*2, x1*2, y1*2)).save(f'{base}_crop{i//4+1}.png')
print('wrote', base + '_preview.png', base + '.jpg', (len(boxes)//4), 'crops')
