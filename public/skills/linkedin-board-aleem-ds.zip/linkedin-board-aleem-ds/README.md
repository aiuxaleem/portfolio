# linkedin-board-aleem-ds

An agent skill that turns a reference infographic into a 1080x1350 LinkedIn board in the Aleem Design System (light mode), writes the post, checks both mechanically, and optionally schedules the post. Start with `SKILL.md`.

Design system: https://github.com/aleemcolaberry/Aleem-Design-System
Fonts: Plus Jakarta Sans and JetBrains Mono (SIL Open Font License), Latin subsets in `fonts/`.

Quick test:

```bash
npm i playwright && npx playwright install chromium && pip install pillow
mkdir -p work && cd work
cp ../templates/board_gen.py demo_gen.py && python3 demo_gen.py
node ../scripts/render.js "$PWD/demo.html" "$PWD/demo.png"
```
