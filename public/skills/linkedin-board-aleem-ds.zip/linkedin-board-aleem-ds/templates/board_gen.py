#!/usr/bin/env python3
"""
Board generator template (Aleem Design System, light mode, 1080x1350).

Copy this file to work/<name>_gen.py, fill in CONTENT, write hero(), run:
    python3 <name>_gen.py && node ../scripts/render.js "$PWD/<name>.html" "$PWD/<name>.png"

The fixed frame (tokens, header, hero shell, cards, strip, footer) comes from templates/board.css.
Only EXTRA (this round's layout classes) and hero() change between boards.
"""
import os, html

NAME = os.path.basename(__file__).replace('_gen.py', '')
HERE = os.path.dirname(os.path.abspath(__file__))
SKILL = os.path.dirname(HERE)                      # skill root when run from work/
CSS = open(os.path.join(SKILL, 'templates', 'board.css')).read()
CSS = CSS.replace("url('fonts/", "url('" + os.path.join(SKILL, 'fonts') + "/")

# ---------------------------------------------------------------- author (edit once, keep for every board)
AUTHOR = {
    'name':   'Your Name',
    'title':  'Your title, one line, as it should appear on every board',
    'avatar': os.path.join(SKILL, 'assets', 'avatar.png'),   # square photo, 512px or larger
}

# ---------------------------------------------------------------- content (edit every board)
CONTENT = {
    'eyebrow':  'Subject of the board',
    'h1':       ('First line of the claim,', 'second line in blue'),
    'sub':      'One to three lines at 15.5px. Say what the reader is looking at and the <b>one thing to notice</b>.',
    'hcard':    ('WHAT CHANGED', 'Short claim for the side card', 'One sentence that the headline does not already say.'),
    'strip':    (('WHY IT MATTERS', '<b>Bold lead.</b> One sentence.'), ('THE TEST', 'One sentence the reader can apply tomorrow.')),
}

# ---------------------------------------------------------------- this round's layout
EXTRA = """
  /* Layout classes for this board only. Keep names unique; .row/.led are not defined here, invent your own. */
  .demo { flex: 1 1 auto; display: grid; grid-template-columns: repeat(3, 1fr); gap: 12px; margin-top: 12px; }
  .demo .t { border-radius: 16px; background: var(--slate-50); border: 1px solid var(--slate-150); padding: 18px; display: flex; flex-direction: column; justify-content: center; }
  .demo .t b { margin-top: 10px; font-weight: 800; font-size: 26px; letter-spacing: -0.03em; color: var(--navy-800); line-height: 1.1; }
  .demo .t p { margin-top: 8px; font-size: 15.5px; line-height: 1.38; color: var(--slate-600); }
  .demo .t .num { font-family: var(--font-mono); font-weight: 800; font-size: 44px; color: var(--blue-700); letter-spacing: -0.03em; }
"""

def hero():
    """Return the inner HTML of the hero. Replace this demo grid with the round's composition
    (an HTML grid, or an inline <svg> whose viewBox equals the hero's inner box, 932 wide)."""
    tiles = ''.join(
        f'<div class="t"><span class="num">0{i}</span><b>Label {i}</b><p>One line per tile, in large type. Detail goes in the post.</p></div>'
        for i in range(1, 7))
    return f'''
    <div class="top"><div class="k">Hero label · <b>what this picture shows</b></div><span class="tag stop">The one accent</span></div>
    <div class="demo">{tiles}</div>'''

# ---------------------------------------------------------------- assembly (normally unchanged)
SAVE_ICON = ('<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">'
             '<path d="M6 3h12a1 1 0 0 1 1 1v17l-7-4-7 4V4a1 1 0 0 1 1-1z"/></svg>')

def esc(s): return html.escape(s, quote=False)

HTML = f"""<!doctype html><html lang="en"><head><meta charset="utf-8"><title>{esc(CONTENT['h1'][0])} {esc(CONTENT['h1'][1])}</title>
<style>{CSS}{EXTRA}</style></head><body>
<div class="board">
  <div class="head">
    <div>
      <div class="eyebrow">{esc(CONTENT['eyebrow'])}</div>
      <h1>{esc(CONTENT['h1'][0])}<br><span>{esc(CONTENT['h1'][1])}</span></h1>
      <p class="sub">{CONTENT['sub']}</p>
    </div>
    <div class="hcard"><div class="k">{esc(CONTENT['hcard'][0])}</div><h2>{esc(CONTENT['hcard'][1])}</h2><p>{CONTENT['hcard'][2]}</p></div>
  </div>
  <div class="hero">{hero()}</div>
  <div class="strip">
    <div><div class="k">{esc(CONTENT['strip'][0][0])}</div><p>{CONTENT['strip'][0][1]}</p></div>
    <div><div class="k">{esc(CONTENT['strip'][1][0])}</div><p>{CONTENT['strip'][1][1]}</p></div>
  </div>
  <div class="foot">
    <div class="whoami"><img src="{AUTHOR['avatar']}" alt="">
      <div><div class="name">{esc(AUTHOR['name'])}</div><div class="title">{esc(AUTHOR['title'])}</div></div></div>
    <div class="save">{SAVE_ICON}Save this post</div>
  </div>
</div></body></html>"""

out = os.path.join(os.getcwd(), NAME + '.html')
open(out, 'w').write(HTML)
print('wrote', out)
