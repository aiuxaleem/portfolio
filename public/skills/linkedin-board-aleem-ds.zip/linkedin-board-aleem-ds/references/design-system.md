# Aleem Design System, light mode, as used on LinkedIn boards

Source of truth: https://github.com/aleemcolaberry/Aleem-Design-System (`tokens/colors.css`, `tokens/typography.css`, `tokens/layout.css`, `tokens/fonts.css`, `CLAUDE.md`). This file is the subset a board needs. `templates/board.css` in this skill carries the same values as CSS; when the repo and this file disagree, the repo wins.

## Colour tokens

| Group | Token | Hex | Use on a board |
|---|---|---|---|
| Ink | `--navy-900` | #06121F | deepest ink, rarely needed |
| Ink | `--navy-800` | #0B1F36 | headlines, dark panels, pills |
| Ink | `--navy-700` | #12304F | second dark fill (for example "people" segments of a wheel) |
| Blue | `--blue-800` | #0F55B2 | top of the panel gradient |
| Blue | `--blue-700` | #1568D4 | eyebrow, emphasis, numbers |
| Blue | `--blue-600` | #1B79EC | start of the text gradient |
| Blue | `--blue-500` | #258AFD | bright accent lines |
| Blue | `--blue-100` | #E6F1FF | light fill (for example "chosen" or "tool" segments) |
| Cyan | `--cyan-700` | #0E7F9E | end of the deep gradient |
| Cyan | `--cyan-500` | #29BEDD | glow, highlights |
| Cyan | `--cyan-400` | #5FD0E8 | mono labels on dark panels |
| Cyan | `--cyan-100` | #E6F8FC | light cyan tint |
| Slate | `--slate-50` | #F4F5FA | the board surface |
| Slate | `--slate-100` | #ECEEF4 | inner surfaces |
| Slate | `--slate-150` | #E2E5EE | card borders |
| Slate | `--slate-200` | #D5D9E4 | inner borders, rails |
| Slate | `--slate-300` | #B9C0D0 | strike-through, outline buttons |
| Slate | `--slate-550` | #636B7E | mono labels |
| Slate | `--slate-600` | #525A6B | body text |
| Slate | `--slate-700` | #3B4253 | base text colour |

Semantic colours. Only the solid values exist as variables; write the deep and tint values as hex.

| Meaning | Solid | Deep | Tint |
|---|---|---|---|
| Pass, kept, puts back | `--green-500` #1FB877 | #0F7A4C | #DDF6EA |
| Caution, prototype, note | `--amber-500` #F5A524 | `--amber-700` #D98B0E | #FFF1D6 |
| Fail, lost, wrong, stop | `--red-500` #E5484D | #B3262B | #FDEDEE (outline #F6C7C9) |

`--red-700` and `--green-700` do not exist. Writing them produces an invisible element, which the renderer will not flag.

## Gradients and shadows

```
--gradient-brand-text: linear-gradient(90deg, #1B79EC 0%, #1193B5 100%)       second line of the h1
--gradient-brand-deep: linear-gradient(135deg, #1568D4 0%, #0E7F9E 100%)      eyebrow bar, small accents
--gradient-panel:      linear-gradient(170deg, #0F55B2 0%, #0B1F36 70%, #0B1F36 100%)   side card, strip, dark tiles
--shadow-md: 0 10px 30px rgba(11,31,54,0.10), 0 2px 6px rgba(11,31,54,0.05)   white cards
--shadow-lg: 0 24px 56px rgba(11,31,54,0.16), 0 4px 12px rgba(11,31,54,0.06)  dark panels
```

Board background: `--slate-50` with a cyan radial glow at the top right (rgba(41,190,221,0.20) fading by 34%) and a blue one at the bottom left (rgba(37,138,253,0.14) fading by 32%).

## Type

Two faces only: Plus Jakarta Sans (display and body, weight 200 to 800) and JetBrains Mono (numbers, keys, badges).

| Role | Face | Size / line | Weight | Tracking | Colour |
|---|---|---|---|---|---|
| Eyebrow | sans | 12.5px | 700 | 0.14em, uppercase | blue-700, with a 26x3 gradient bar before it |
| h1, two lines | sans | 44px / 1.02 | 800 | -0.04em | navy-800; second line in gradient-brand-text |
| Sub | sans | 15.5px / 1.45, max-width 640, at most 3 lines | 400, bold 700 | | slate-600, bold navy-800 |
| Mono label `.k` | mono | 10px (9.5 in cards) | 700 | 0.12em, uppercase | slate-550; cyan-400 on dark |
| Side card h2 | sans | 21px / 1.08 | 800 | -0.03em | white |
| Side card and strip body | sans | 13px / 1.4 | 400, bold 800 | | white at 84 to 86% |
| Card h3 | sans | 15px / 1.12 | 800 | -0.02em | navy-800 |
| Card body | sans | 12px / 1.38 | 400 | | slate-600 |
| Footer name | sans | 19px / 1.15 | 800 | -0.015em | navy-800 |
| Footer title | sans | 13.5px, one line | 400 | | slate-600 |
| Save pill | sans | 15px | 700 | | white on navy-800 |

Board text rule: anything the reader must read on the feed is at least 15px at 1x, ideally 17px and up. Labels inside diagrams are 11 to 13px mono. Nothing anywhere below 8.5px. Explanations go in the post, not on the board.

## Parts of a board

Every board is a flex column `.board` of 1080x1350 with padding 46px 56px 42px (inner area 968x1262):

- `.head`: grid `minmax(0,1fr) 300px`, gap 22. Left: `.eyebrow`, `h1` (two lines, second in `<span>`), `.sub`. Right: `.hcard` (radius 20, gradient-panel, shadow-lg, padding 16/18/14) with a `.k` label, `h2` and one `p`.
- `.hero`: `flex: 1 1 auto`, white, radius 22, 1px slate-150 border, shadow-md, padding 14/18/12. Holds the round's composition. An SVG hero uses a viewBox equal to the hero's inner box (932 wide) and `preserveAspectRatio="xMidYMid meet"`; never `slice`.
- `.cards` (optional): a grid of `.card` (white, radius 18, border slate-150, shadow-md, padding 11/15/10). Put `.grow` on the card that should absorb spare height.
- `.strip`: dark, radius 18, gradient-panel, grid `1.15fr 1fr`, two cells with a `.k` label and one `p` each: why it matters, and the test.
- `.foot`: `.whoami` (60px round photo, name, title) and the `.save` pill (height 48, radius 999, navy-800).

Radii: 22 hero, 20 side card, 18 cards and strip, 12 to 16 inner tiles, 999 pills. Gaps: 12 to 14 between sections, 10 to 12 inside grids.

## Fixed rules

1. Light mode only. Dark is a panel colour (side card, strip, hub of a wheel, dark tiles), never the board.
2. Two typefaces, no others. Plus Jakarta Sans 800 for display; JetBrains Mono for numbers, keys, badges.
3. Real brand marks or none. A logo is cropped from a real source or captured from the brand's own site at 36 to 64px. If no real mark is available, the brand is set in text. Never draw a stand-in for a logo.
4. Original icons for abstract concepts: 24px stroke SVGs, stroke 2 to 2.2, round caps and joins.
5. One accent per board. A single red or amber element carries the point (Von Restorff spent once). Everything else stays navy, blue, cyan, slate.
6. The footer is identical on every board: the author's photo, name and one-line title. The author's details are configured once in the generator.
7. No em dashes, no emoji, no ellipses, on the board or in the post.
8. No clipped text, no overflow, no half-empty hero. The renderer's `bad` array must be empty and the hero must fill the space the header leaves.

## Credit

The system is by Md Abdul Aleem (aiuxaleem.com). When sharing boards made with it, a line such as "Design system: Aleem Design System" in the post or profile is welcome but not required.
