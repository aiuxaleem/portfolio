# Compositions, the audit, and what the renderer misses

## Choosing a composition

No two consecutive boards share a hero shape. Keep a one-line note of each shape used in `work/queue-log.md` and pick something different from the last two.

Shapes that have worked, with when to use them:

| Shape | Good for |
|---|---|
| Bento grid (one 2x2 feature tile plus small tiles) | a list of six to eight items with one that matters most |
| Funnel or stacked 3D bands | layers, levels, a hierarchy where each step gives something up |
| Pyramid | foundations and what sits on them |
| Twelve-segment wheel | a cycle, categories around a hub, two groups shown by fill colour |
| Concentric rings | scope, from core to edge |
| Iceberg | what is visible versus what carries the weight |
| Transit map | several paths through the same stops, where each path adds or skips one |
| Timeline or night-shift axis | events over hours, days or a shift |
| Vertical Gantt with side labels | a plan over days or weeks |
| Tier list | sorting items into keep, borrow, one-off |
| Browser-window or phone mock | a UI claim; show two exchanges so the window is not empty |
| Swimlanes | who does what, across roles or systems |
| Convergence diagram | several inputs becoming one decision |
| Illustrated rows | an analogy, one drawn figure plus object per row |
| Receipt tape | costs and totals |
| Building cross-section | floors as layers with people on each |

When the author says they like the reference's layout, keep that shape and redraw it from scratch in the system. Never trace or recolour the reference.

Decide four things before writing any code: the one-sentence claim (the h1), the one oversized element in the hero, the two strip sentences (why it matters, the test), and which single element carries the red or amber accent.

## Drawing in code

- HTML grids for cards and tiles; inline SVG for diagrams. Build SVG with small Python helpers: `pol(r, deg)` for polar points, wedge paths for wheels, truncated cones for funnels, `textPath` for curved labels, one `clipPath` per image wrapped in a `<g transform>`, `<marker>` arrowheads, gradients defined once in `<defs>`.
- Size the SVG viewBox to the hero's inner box (932 wide by the height the header leaves; measure it) and use `preserveAspectRatio="xMidYMid meet"`.
- Fit the words to the slot before rendering: about 17 characters per line in a 146px card at 13px, 24 characters in a 164px card, labels tangential rather than radial on the 3 and 9 o'clock segments of a wheel.
- Brand marks: crop from the reference image with PIL, or capture from the brand's own site. Place at 36 to 64px inside a white circle or tile. No mark available: write the name in text.

## Render loop

```bash
cd work
python3 <name>_gen.py
node ../scripts/render.js "$PWD/<name>.html" "$PWD/<name>.png"
node ../scripts/measure.js "$PWD/<name>.html" ".head,.hero,.strip,.foot,.hero svg"
python3 ../scripts/export.py <name>.png  [x0 y0 x1 y1 ...]
```

1. `render.js` prints the fonts loaded and a `bad` array. Both fonts must say `loaded`. Loop until `bad` is `[]`.
2. `measure.js` prints each section's box and content bottom. Head, hero, strip and foot with their gaps must fill 1262px. If the hero's content bottom sits well above the hero's bottom, the hero is half empty: enlarge the picture, add a legend or key, or add content.
3. Open `<name>_preview.png` (1x) and look at it as a reader would, then the 2x crops of dense areas.

## What the renderer cannot see

The `bad` array catches clipped HTML text and cards that overflow their box. It does not catch:

- text inside an SVG running past its box or over a mark
- elements with `overflow: visible` spilling into a neighbour
- a `white-space: nowrap` rail wider than its container
- cards in a grid row taller than the row, pushing the strip down
- a sub that runs to four lines
- a hero whose SVG leaves white space at the bottom
- the accent colour used twice
- a brand mark that is blurry at 2x
- a footer title that wraps
- a generic `svg { width: ... }` rule that resizes every inline icon in the same container (scope such rules: `.card > svg`)

Look for each of these by eye in the preview and the crops.

## Audit and rating

Score the finished board from 1 to 10 against these, and write the score down in the log. Below 7, rework; do not ship.

1. Above the fold (top 45%): the headline reads in one glance, the hero is visibly full, one element stops the scroll.
2. Common region: cards and panels group the right things together.
3. Similarity: things with the same role look the same.
4. Von Restorff: exactly one element stands out, and it is the point.
5. Serial position: the claim is at the top (h1), the test is at the bottom (strip).
6. Miller: no group has more than seven items.
7. Jakob: anything that imitates a UI behaves like the real one.
8. Legibility: every word readable at feed size on a phone; nothing under 8.5px.
9. Honesty: real marks or none; no fake data; the author's footer, nobody else's branding.

Typical fixes that lift a score: shorten labels, widen a column, place wheel labels tangentially, enlarge type, remove a card so the hero can grow, add a second exchange to a mock, move a key into a pill at a corner.

## Pitfalls recorded

- `preserveAspectRatio="slice"` crops side content; use `meet`.
- `str.replace` on a shared substring edits more than intended; replace whole tags or use unique markers.
- `--red-700` and `--green-700` are not tokens; use #B3262B and #0F7A4C.
- A board's own class names must not collide with the frame's (`.k`, `.head`, `.hero`, `.cards`, `.card`, `.strip`, `.foot`, `.whoami`, `.save`, `.tag`).
- Fonts not loading (`unloaded` in the render output) means the `fonts/` path in `board.css` did not resolve; the generator rewrites it to an absolute path, so run the generator from `work/` or `templates/`.
