# Scheduling on LinkedIn

Scheduling is optional. If no browser automation is available, hand the author the PNG and the checked post text and stop. If it is available (for example Claude in Chrome or another browser-automation tool working in the author's own signed-in browser), follow this brief exactly.

## Safety rules, non-negotiable

- Never click Post. The only publishing action is Schedule, and the run ends at the "Post scheduled" confirmation.
- Never enter, read or store a password, one-time code or cookie. If LinkedIn asks for sign-in, stop and tell the author.
- Never click the link inside the confirmation toast, never open the published post, never like or comment.
- Never dismiss the composer with "Save as draft" unless the author asks for it.
- Type the post text once. If the typing action times out, wait; the page may freeze for up to four minutes while it catches up. Verify by reading the editor back, never by retyping.
- Report what was done in one fixed sentence: "Scheduled for <date> 7:00 AM <timezone>; queue now <N>; newest entry <title>."

## Steps

1. Copy the final PNG to the path the browser tool can upload from (for Claude in Chrome this is `/mnt/user-data/uploads/<name>.png`).
2. Open linkedin.com/feed and start a post. The editor is `div.tiptap.ProseMirror[role=textbox][contenteditable=true]`.
3. Add the image through the Media button. The button creates an `input[type=file]` on click; a browser tool usually has to intercept it (patch `HTMLInputElement.prototype.click` and `showPicker`, find the input, upload). The image editor shows "1 of 1"; click Next. Confirm the preview image is 2160x2700.
4. Paste or type the post text once. Verify by JavaScript: character count equals the file, first line and last line match, paragraph count matches.
5. Open the schedule control (`a[aria-label="Scheduled"]`), tab "Schedule post". Date as `M/D/YYYY`, time 7:00 AM (a `div[role=menuitemradio]`), Confirm, then Schedule. The toast arrives about 12 seconds later.
6. Reopen the Scheduled list (it lazy-loads: two real mouse-wheel scrolls start it), confirm the count rose by one and the newest entry has the new date.
7. Append the slot to `work/queue-log.md`.

## The 90-day window

LinkedIn accepts a schedule date up to today plus 89 days. With a full queue, exactly one new slot opens each day at midnight local time. Build boards ahead; book one per morning in date order.

## Queue log

`work/queue-log.md`, one line per slot, newest last:

```
- 2027-02-10 07:00 | <name> | <board title> | BUILT or SCHEDULED
  ref: <reference described, no author name> | angle: <one-sentence claim>
  composition: <shape> | accent: <element> | marks: <sets or none>
  verified: <facts checked> | post: <chars> chars, <n> spacers, <hashtags> | score: <n>/10
  lesson: <anything the renderer or the composer taught>
```

Read this file first every morning. It is what makes the duplicate check possible.
