# Writing the post

The board carries the claim in large type. The post carries the argument. Write the post after the board is final, so it explains what is actually on the picture.

## Shape

- First line: concrete and specific. A scene, an observation, a named thing. Never a number or statistic, never a question, never "I".
- One idea per short paragraph, two to four sentences each. Plain, medium-length sentences.
- Every blank line between paragraphs holds a single U+2800 (braille blank) character, alone on the line. LinkedIn collapses truly empty lines; this keeps the spacing.
- Middle: what the reference card gets right, then the one thing it leaves out or gets wrong, then what the author would do about it, grounded in the author's own experience.
- Close with one direct question to readers, then a spacer line, then two or three hashtags. Vary the hashtags from day to day.
- Length: under 3,000 characters with at least 40 to spare. 2,500 to 2,950 is the working range.

## Rules

- No em dashes, no en dashes, no emoji, no ellipses.
- No links in the body. Nothing "in the comments" or "in the first comment". The post stands on its own with the image.
- Never mention like, repost or comment counts.
- Never name the person whose LinkedIn content the reference came from. Describe it: "a card going around this week", "the six-layer map going around". Brands, products, books and published frameworks may be named.
- Never invent the author's projects, numbers, employers, tools, results or usage. Where the author has not stated a fact, write it as a view: "I would", "the rule I would give". If a detail is needed and unknown, ask the author before writing.
- Keep client work generic: "an AI tool for a client in freight", never the client's name.
- Verify facts taken from the reference card (prices, licence terms, regulator names, product features) before repeating them. If the card is wrong, the post corrects it rather than passing it on.
- Credible senior voice: no hype, no buzzword stacks, no exaggerated claims, no performed sincerity.

## Check before scheduling

```bash
python3 scripts/check_post.py work/<name>-post.txt
```

It trims trailing newlines in place and reports length, dashes, emoji, spacer count, first-line and last-line rules, links and empty blank lines. Fix everything it lists.

## Humanizing

If the `linkedin-skills` collection (https://github.com/sergebulaev/linkedin-skills, MIT) is installed, run its Post Writer for the hook and structure and its Humanizer on the draft before the check above. It strips the patterns that make a post read as machine-written: stacked triads, reveal bridges, staccato fragments, performed sincerity. Then re-run `check_post.py`, because the humanizer may change the length.

## Skeleton

```
<Concrete opening line about the thing on the board.>
⠀
<What the card going around says, and what is right about it.>
⠀
<The one thing it leaves out, or the detail a practitioner notices.>
⠀
<What I would do about it, from experience. Two or three short paragraphs.>
⠀
<The test or rule the reader can apply tomorrow.>
⠀
<One direct question to readers?>
⠀
#Tag1 #Tag2 #Tag3
```
