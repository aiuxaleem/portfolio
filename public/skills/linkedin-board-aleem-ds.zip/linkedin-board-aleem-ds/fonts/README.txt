Plus Jakarta Sans (Tokotype) and JetBrains Mono (JetBrains) are licensed under the SIL Open Font License 1.1.
The two files here are Latin-subset variable builds used for rendering boards offline.
Full families: https://fonts.google.com/specimen/Plus+Jakarta+Sans and https://fonts.google.com/specimen/JetBrains+Mono
If a board needs non-Latin glyphs, replace these files with the full variable woff2 builds; the file names must stay the same.
