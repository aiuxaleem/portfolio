# reel-to-linkedin-post

A Claude skill by Md Abdul Aleem. Turn a short-form video file (Reel, Short, TikTok) into a caption-accurate transcript, per-step key frames, a where-to-find-it guide and one copy-ready LinkedIn post.

## Files
- `SKILL.md`: the skill. Save it as a skill in Claude, or copy this folder into `.claude/skills/` for Claude Code.
- `scripts/sheets.py`: 1 fps frames to labelled 4x4 contact sheets
- `scripts/captions.py`: caption-band OCR at 4 fps (tesseract), de-duplicated and timestamped
- `scripts/keyframes.py`: full-resolution key frames per step, card or full-screen crops
- `scripts/check_post.py`: the post rules check; writes the U+2800-spaced copy
- `scripts/card.py`: the copy-card HTML for the post

The same five scripts are embedded in `SKILL.md`, so the skill works on its own; the copies here are for reading and reuse.

## Needs
ffmpeg and ffprobe, tesseract, Python 3 with Pillow, pytesseract and numpy. No network is required for the extraction; the research step uses web search.

## Rules it enforces in the post
Hook in the reel's structure, never its words. Never a number or a question first. One reel instruction plus one design-terms sentence per step. No links, no creator names, no "comment X" gates. One closing question, two or three hashtags, under 3,000 characters with the braille-blank spacers in.
