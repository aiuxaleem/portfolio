# card.py  -> first-agent-post.html (reads post_spaced.txt)
import json; s=open('post_spaced.txt').read(); n=len(s)
open('post-card.html','w').write(f'''<title>First Agent Post</title>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;600;700&display=swap">
<style>:root{{--bg:#f4f7fb;--card:#fff;--fg:#0b1a33;--muted:#52627a;--line:#d9e2ee;--a:#0b57d0;--b:#13b6d9}}
@media (prefers-color-scheme:dark){{:root:not([data-theme="light"]){{--bg:#0b1324;--card:#121c31;--fg:#e8eef8;--muted:#9fb0c8;--line:#243352;--a:#6aa5ff;--b:#35c8e6;color-scheme:dark}}}}
:root[data-theme="dark"]{{--bg:#0b1324;--card:#121c31;--fg:#e8eef8;--muted:#9fb0c8;--line:#243352;--a:#6aa5ff;--b:#35c8e6;color-scheme:dark}}
body{{background:var(--bg);color:var(--fg);font-family:"Plus Jakarta Sans",system-ui,sans-serif;margin:0;padding-block:28px 48px;padding-left:max(16px,env(safe-area-inset-left,0px));padding-right:max(16px,env(safe-area-inset-right,0px))}}
main{{max-width:680px;margin:0 auto;display:grid;gap:18px}}h1{{font-size:1.35rem;margin:0}}
.bar{{display:flex;flex-wrap:wrap;gap:12px;align-items:center;justify-content:space-between}}.meta{{font-size:.8rem;color:var(--muted)}}
button{{font:600 .95rem inherit;color:#fff;border:0;border-radius:10px;padding:12px 20px;cursor:pointer;background:linear-gradient(90deg,var(--a),var(--b))}}
.card{{background:var(--card);border:1px solid var(--line);border-radius:14px;padding:22px;min-width:0}}pre{{margin:0;white-space:pre-wrap;overflow-wrap:anywhere;font:400 1rem/1.6 inherit}}</style>
<main><h1>Your first AI agent in five steps</h1><div class="bar"><button id="c" type="button">Copy post</button><div class="meta">{n} characters, spacers included</div></div>
<section class="card"><pre id="p"></pre></section></main>
<script>(function(){{var t={json.dumps(s,ensure_ascii=False)};var p=document.getElementById('p');p.textContent=t;var b=document.getElementById('c');
function sel(){{var r=document.createRange();r.selectNodeContents(p);var x=getSelection();x.removeAllRanges();x.addRange(r);b.textContent='Selected, press Ctrl+C'}}
b.onclick=function(){{try{{navigator.clipboard.writeText(t).then(function(){{b.textContent='Copied';setTimeout(function(){{b.textContent='Copy post'}},2200)}},sel)}}catch(e){{sel()}}}}}})();</script>''')
