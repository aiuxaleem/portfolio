# sheets.py <frames_dir> <out_prefix>   (16 frames per sheet, t= label on each cell)
from PIL import Image, ImageDraw; import glob, os, sys
files=sorted(glob.glob(f'{sys.argv[1]}/f_*.jpg')); W,H=Image.open(files[0]).size
for s in range(0,len(files),16):
    sheet=Image.new('RGB',(4*W,4*H),'white'); d=ImageDraw.Draw(sheet)
    for i,f in enumerate(files[s:s+16]):
        x,y=(i%4)*W,(i//4)*H; sheet.paste(Image.open(f),(x,y))
        d.rectangle([x,y,x+70,y+26],fill='black'); d.text((x+6,y+6),f"t={int(os.path.basename(f)[2:5])-1}s",fill='yellow')
    sheet.save(f'{sys.argv[2]}_{s//16+1}.jpg',quality=85)
