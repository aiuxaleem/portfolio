# check_post.py post.txt
import sys, re
t=open(sys.argv[1]).read().rstrip('\n'); L=t.split('\n'); first=L[0].strip(); bad=[]
if re.match(r'^\d',first) or first.endswith('?'): bad.append('hook is a number or a question')
if re.match(r"^(here's|here is|stop )",first.lower()): bad.append("hook opens with Here's or Stop")
if '—' in t or '–' in t: bad.append('dash')   # em dash, en dash
if any(ord(c)>0x2FFF for c in t): bad.append('emoji or symbol')
if 'http' in t or 'comment' in t.lower(): bad.append('link or comment mention')
tags=[w for w in t.split() if w.startswith('#')]
if not 2<=len(tags)<=3: bad.append(f'{len(tags)} hashtags')
body=[l for l in L if l.strip() and not l.strip().startswith('#')]
if not body[-1].strip().endswith('?'): bad.append('no closing question before the hashtags')
spaced='\n'.join(l if l.strip() else '⠀' for l in L); open('post_spaced.txt','w').write(spaced)   # braille blank keeps LinkedIn spacing
if len(spaced)>2960: bad.append(f'{len(spaced)} chars with spacers')
print('OK' if not bad else 'FIX: '+'; '.join(bad), len(spaced),'chars')
