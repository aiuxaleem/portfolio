# keyframes.py <video> spec.txt     spec lines:  <label>|<seconds>|card|full
import subprocess, sys, os, numpy as np
from PIL import Image
v=sys.argv[1]; os.makedirs('out',exist_ok=True)
for line in open(sys.argv[2]):
    if not line.strip(): continue
    label,t,kind=[s.strip() for s in line.split('|')]
    subprocess.run(['ffmpeg','-v','error','-y','-ss',t,'-i',v,'-frames:v','1','key.png'],check=True)
    im=Image.open('key.png'); a=np.asarray(im.convert('L'))
    if kind=='card':
        br=a>228; rows=np.where(br[:int(a.shape[0]*0.45)].mean(1)>0.55)[0]
        y0,y1=max(0,rows.min()-10),rows.max()+10; cols=np.where(br[y0:y1].mean(0)>0.5)[0]
        im=im.crop((max(0,cols.min()-10),y0,min(im.width,cols.max()+10),y1))
    else:
        im=im.crop((0,int(im.height*0.085),im.width,int(im.height*0.71)))
    im.save(f"out/{label}.png")
