# captions.py <video> <band_top_frac> <band_bottom_frac>   e.g. 0.72 0.83 for a band centred at 77% of the height
import subprocess, sys, glob, os, re
from PIL import Image; import pytesseract
v,top,bot=sys.argv[1],float(sys.argv[2]),float(sys.argv[3])
w,h=[int(x) for x in subprocess.check_output(['ffprobe','-v','error','-select_streams','v:0',
     '-show_entries','stream=width,height','-of','csv=p=0',v]).decode().strip().split(',')]
os.makedirs('cap',exist_ok=True)
subprocess.run(['ffmpeg','-v','error','-y','-i',v,'-vf',f'fps=4,crop={w}:{int((bot-top)*h)}:0:{int(top*h)}','cap/c_%04d.png'],check=True)
prev=None
for f in sorted(glob.glob('cap/c_*.png')):
    im=Image.open(f).convert('L').point(lambda p:0 if p>150 else 255)   # light text on a dark box -> black on white; flip for dark text
    im=im.resize((im.width*2,im.height*2))
    t=' '.join(re.sub(r"[^A-Za-z0-9 ,.'\-\"]",'',pytesseract.image_to_string(im,config='--psm 6')).split())
    if t and t!=prev: print(f"{(int(os.path.basename(f)[2:6])-1)/4:6.2f}  {t}"); prev=t
