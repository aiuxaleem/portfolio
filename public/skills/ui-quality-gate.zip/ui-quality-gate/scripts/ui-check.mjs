#!/usr/bin/env node
// ui-check.mjs: part of the ui-quality-gate skill by Mohammad Abdul Aleem (aiuxaleem-portfolio-app.vercel.app).
// Opens every page at ten widths in light and dark and records what a person and an agent would trip over:
// axe-core violations (WCAG 2.2 A/AA), sideways scroll, text cut off inside its box, touch targets under 24 px,
// images without alt, a viewport that blocks zoom, the h1 count and skipped heading levels, and the landmarks.
//
// Needs: npm i -D playwright-core axe-core, and Chrome, Edge or a Playwright Chromium on the machine.
// Usage:  node ui-check.mjs <url> [<url> ...] [options]
//         node ui-check.mjs --sitemap=<sitemap url> [options]
// Options: --widths=320,390,1440 | --quick (390 and 1440) | --themes=light,dark | --theme-attr=data-theme
//          --shots | --out=reports/ui-check | --channel=chrome|msedge|chromium | --max=50 (pages from a sitemap)
import fs from 'node:fs';
import path from 'node:path';
import { chromium } from 'playwright-core';

const DEFAULT_WIDTHS = ['320', '360', '390', '414', '768', '1024', '1280', '1440', '1920', '844x390'];
const args = process.argv.slice(2);
const opt = (name, fallback) => {
  const a = args.find(x => x.startsWith(`--${name}=`));
  return a ? a.slice(name.length + 3) : fallback;
};
const flag = name => args.includes(`--${name}`);

const widths = flag('quick') ? ['390', '1440'] : opt('widths', DEFAULT_WIDTHS.join(',')).split(',').map(s => s.trim()).filter(Boolean);
const themes = opt('themes', 'light,dark').split(',').map(s => s.trim()).filter(Boolean);
const themeAttr = opt('theme-attr', '');
const outDir = opt('out', 'reports/ui-check');
const shots = flag('shots');
const max = Number(opt('max', '50'));

async function pagesFromSitemap(url, seen = new Set()) {
  if (seen.has(url)) return [];
  seen.add(url);
  const res = await fetch(url);
  if (!res.ok) throw new Error(`Sitemap ${url} answered ${res.status}`);
  const locs = [...(await res.text()).matchAll(/<loc>\s*([^<\s]+)\s*<\/loc>/g)].map(m => m[1]);
  const out = [];
  for (const loc of locs) {
    if (/sitemap[^/]*\.xml$/i.test(loc)) out.push(...await pagesFromSitemap(loc, seen));
    else out.push(loc);
  }
  return out;
}

async function launch() {
  const wanted = opt('channel', '');
  const order = wanted ? [wanted] : ['chrome', 'msedge', 'chromium'];
  for (const channel of order) {
    try {
      return await chromium.launch(channel === 'chromium' ? {} : { channel });
    } catch { /* try the next browser */ }
  }
  throw new Error('No browser found. Install Chrome or Edge, or run: npx playwright install chromium');
}

function size(w) {
  const [width, height] = w.includes('x') ? w.split('x').map(Number) : [Number(w), Number(w) < 768 ? 800 : 900];
  return { width, height };
}

// Runs inside the page. Returns the measurements for one view.
function measure() {
  const vis = el => {
    const s = getComputedStyle(el);
    if (s.display === 'none' || s.visibility === 'hidden' || Number(s.opacity) === 0) return false;
    const b = el.getBoundingClientRect();
    return b.width > 0 && b.height > 0;
  };
  const where = el => {
    const parts = [];
    for (let e = el; e && e.nodeType === 1 && parts.length < 4; e = e.parentElement) {
      if (e.id) { parts.unshift(`#${CSS.escape(e.id)}`); break; }
      let p = e.tagName.toLowerCase();
      if (e.classList.length) p += '.' + [...e.classList].slice(0, 2).map(c => CSS.escape(c)).join('.');
      parts.unshift(p);
    }
    return parts.join(' > ');
  };
  const doc = document.documentElement;

  // Sideways scroll on the page itself.
  const sideways = Math.max(0, doc.scrollWidth - doc.clientWidth);

  // Text partly outside a box that hides overflow (wholly outside is off-screen content such as a carousel slide).
  const clipped = [];
  const hides = v => v === 'hidden' || v === 'clip';
  const scrolls = v => v === 'auto' || v === 'scroll';
  const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
  let n = 0;
  for (let t = walker.nextNode(); t && n < 6000 && clipped.length < 15; t = walker.nextNode()) {
    if (!t.textContent.trim()) continue;
    const host = t.parentElement;
    if (!host || !vis(host) || host.closest('script,style,noscript,template,svg')) continue;
    n++;
    const range = document.createRange();
    range.selectNodeContents(t);
    const r = range.getBoundingClientRect();
    if (r.width === 0 || r.height === 0) continue;
    for (let a = host; a && a !== document.body; a = a.parentElement) {
      const s = getComputedStyle(a);
      if (scrolls(s.overflowX) || scrolls(s.overflowY)) break;
      if (!hides(s.overflowX) && !hides(s.overflowY)) continue;
      const b = a.getBoundingClientRect();
      if (b.width <= 2 || b.height <= 2) break; // a visually hidden label
      if (s.textOverflow === 'ellipsis' || (s.webkitLineClamp && s.webkitLineClamp !== 'none')) break; // deliberate truncation
      const outX = hides(s.overflowX) && (r.left < b.left - 1 || r.right > b.right + 1);
      const outY = hides(s.overflowY) && (r.top < b.top - 1 || r.bottom > b.bottom + 1);
      const overlaps = r.right > b.left && r.left < b.right && r.bottom > b.top && r.top < b.bottom;
      if ((outX || outY) && overlaps) clipped.push({ where: where(a), text: t.textContent.trim().slice(0, 60) });
      break;
    }
  }

  // Touch targets (2.5.8): under 24 px fails, under 44 px is a note. Inline links in running text are exempt.
  const small = [], under44 = [];
  const targets = document.querySelectorAll('a[href],button,input:not([type=hidden]),select,textarea,summary,[role=button],[role=link],[role=tab],[role=checkbox],[role=switch]');
  for (const el of targets) {
    if (!vis(el)) continue;
    if (el.tagName === 'A' && getComputedStyle(el).display === 'inline') continue;
    const b = el.getBoundingClientRect();
    if (b.width < 2 || b.height < 2) continue; // visually hidden until focused (a skip link)
    const label = (el.getAttribute('aria-label') || el.textContent || el.getAttribute('title') || '').trim().slice(0, 40);
    if (b.width < 24 || b.height < 24) small.push({ where: where(el), label, size: `${Math.round(b.width)}x${Math.round(b.height)}` });
    else if (b.width < 44 || b.height < 44) under44.push({ where: where(el), label, size: `${Math.round(b.width)}x${Math.round(b.height)}` });
  }

  // Images.
  const imgs = [...document.images];
  const noAlt = imgs.filter(i => !i.hasAttribute('alt')).map(i => where(i));
  // Without width and height a picture can shift the layout as it loads. Not counted: one with no file yet (a lightbox filled
  // on demand) and one taken out of the flow (absolute or fixed, sized by its box), since neither can move the page.
  const noSize = imgs.filter(i => i.getAttribute('src') && !['absolute', 'fixed'].includes(getComputedStyle(i).position) && !(i.getAttribute('width') && i.getAttribute('height')) && getComputedStyle(i).aspectRatio === 'auto').map(i => where(i));

  // Zoom.
  const vp = document.querySelector('meta[name=viewport]')?.getAttribute('content') || '';
  const maxScale = /maximum-scale\s*=\s*([\d.]+)/i.exec(vp);
  const zoomBlocked = /user-scalable\s*=\s*(no|0)/i.test(vp) || (maxScale && Number(maxScale[1]) < 2);

  // Headings: the outline an agent and a screen reader use.
  const heads = [...document.querySelectorAll('h1,h2,h3,h4,h5,h6,[role=heading]')].filter(vis).map(h => ({
    level: h.getAttribute('aria-level') ? Number(h.getAttribute('aria-level')) : Number(h.tagName[1]) || 2,
    text: h.textContent.trim().slice(0, 60),
  }));
  const h1 = heads.filter(h => h.level === 1).length;
  const skipped = [];
  for (let i = 1; i < heads.length; i++) if (heads[i].level > heads[i - 1].level + 1) skipped.push(`h${heads[i - 1].level} to h${heads[i].level}: ${heads[i].text}`);

  // Landmarks.
  const count = s => document.querySelectorAll(s).length;
  const landmarks = {
    header: count('header,[role=banner]'),
    nav: count('nav,[role=navigation]'),
    main: count('main,[role=main]'),
    footer: count('footer,[role=contentinfo]'),
  };

  return { sideways, clipped, small, under44: under44.length, under44Sample: under44.slice(0, 5), noAlt, noSize: noSize.length, zoomBlocked: !!zoomBlocked, h1, skipped, landmarks, title: document.title };
}

async function main() {
  let urls = args.filter(a => !a.startsWith('--'));
  const sitemap = opt('sitemap', '');
  if (sitemap) urls.push(...(await pagesFromSitemap(sitemap)).slice(0, max));
  urls = [...new Set(urls)];
  if (!urls.length) {
    console.error('Give at least one URL, or --sitemap=<url>. See the comment at the top of this file.');
    process.exit(2);
  }
  const axeSource = (await import('axe-core')).default.source;
  fs.mkdirSync(outDir, { recursive: true });
  const started = Date.now();
  const browser = await launch();
  const results = [];
  let failed = 0;

  for (const url of urls) {
    for (const theme of themes) {
      const context = await browser.newContext({ colorScheme: theme === 'dark' ? 'dark' : 'light', reducedMotion: 'reduce' });
      const page = await context.newPage();
      for (const w of widths) {
        const view = { url, theme, width: w };
        try {
          await page.setViewportSize(size(w));
          await page.goto(url, { waitUntil: 'load', timeout: 60_000 });
          if (themeAttr) await page.evaluate(([a, t]) => document.documentElement.setAttribute(a, t), [themeAttr, theme]);
          // Bring lazy content in, then return to the top.
          await page.evaluate(async () => {
            for (let y = 0; y < document.documentElement.scrollHeight; y += innerHeight) { scrollTo(0, y); await new Promise(r => setTimeout(r, 60)); }
            scrollTo(0, 0);
          });
          await page.waitForTimeout(250);
          const m = await page.evaluate(measure);
          await page.addScriptTag({ content: axeSource });
          const axe = await page.evaluate(async () => {
            const r = await window.axe.run(document, { runOnly: { type: 'tag', values: ['wcag2a', 'wcag2aa', 'wcag21a', 'wcag21aa', 'wcag22aa'] }, resultTypes: ['violations'] });
            return r.violations.map(v => ({ id: v.id, impact: v.impact, nodes: v.nodes.length, first: v.nodes[0]?.target.join(' ') }));
          });
          const fails = [];
          if (axe.length) fails.push(`axe ${axe.map(a => a.id).join(', ')}`);
          if (m.sideways > 1) fails.push(`sideways scroll ${m.sideways}px`);
          if (m.clipped.length) fails.push(`${m.clipped.length} text cut off`);
          if (m.small.length) fails.push(`${m.small.length} targets under 24px`);
          if (m.noAlt.length) fails.push(`${m.noAlt.length} images without alt`);
          if (m.zoomBlocked) fails.push('zoom blocked');
          if (m.h1 !== 1) fails.push(`${m.h1} h1`);
          if (m.skipped.length) fails.push(`${m.skipped.length} skipped heading levels`);
          if (m.landmarks.main !== 1) fails.push(`${m.landmarks.main} main landmarks`);
          const notes = [];
          if (m.under44) notes.push(`${m.under44} targets under 44px`);
          if (m.noSize) notes.push(`${m.noSize} images without width and height`);
          for (const k of ['header', 'nav', 'footer']) if (!m.landmarks[k]) notes.push(`no ${k}`);
          if (shots) {
            const name = `${new URL(url).pathname.replace(/[^a-z0-9]+/gi, '-').replace(/^-|-$/g, '') || 'home'}_${w}_${theme}.png`;
            await page.screenshot({ path: path.join(outDir, name), fullPage: true });
            view.shot = name;
          }
          Object.assign(view, { ok: !fails.length, fails, notes, axe, ...m });
        } catch (e) {
          Object.assign(view, { ok: false, fails: [`could not check: ${e.message.split('\n')[0]}`], notes: [] });
        }
        if (!view.ok) failed++;
        results.push(view);
        console.log(`${view.ok ? 'PASS' : 'FAIL'}  ${url}  ${w}  ${theme}${view.fails.length ? '  ' + view.fails.join('; ') : ''}${view.notes.length ? '  (notes: ' + view.notes.join('; ') + ')' : ''}`);
      }
      await context.close();
    }
  }
  const browserVersion = browser.version();
  await browser.close();
  const seconds = Math.round((Date.now() - started) / 1000);
  const summary = { pages: urls.length, views: results.length, failed, seconds, widths, themes, browser: browserVersion, at: new Date().toISOString() };
  fs.writeFileSync(path.join(outDir, 'results.json'), JSON.stringify({ summary, results }, null, 1));
  console.log(`\n${urls.length} pages, ${results.length} views, ${seconds} s. Details in ${path.join(outDir, 'results.json')}`);
  console.log(failed ? `FAILED ${failed}` : 'PASSED');
  process.exit(failed ? 1 : 0);
}

main().catch(e => { console.error(e); process.exit(2); });
