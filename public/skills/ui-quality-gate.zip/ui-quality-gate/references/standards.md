# The standards, as a checklist

Each item applies to every page, component and state, in both themes, at every test width. Items marked (script) are measured by `scripts/ui-check.mjs`; the rest are checked by hand.

Test widths: 320, 360, 390, 414, 768, 1024, 1280, 1440, 1920, and 844×390 landscape.

## 1. Accessibility (WCAG 2.2 AA)
- [ ] Landmarks: header, nav, main, footer (script). One h1, no skipped heading levels (script).
- [ ] Every control works by keyboard, in a logical order, with no trap. A skip-to-content link is the first stop.
- [ ] Every interactive element has a visible `:focus-visible` style, never hidden behind a sticky header (2.4.11).
- [ ] Every image has meaningful alt text, or `alt=""` when decorative (script finds missing alt). Icon-only buttons have names.
- [ ] Form fields have visible labels; errors are tied to their field with `aria-describedby` and announced.
- [ ] The page works at 200% zoom, reflows at 320 CSS px (1.4.10), and survives the text-spacing override (1.4.12).
- [ ] Colour is never the only way meaning is shown.
- [ ] axe-core reports no violations (script).

## 2. Contrast, in every state and both themes
- [ ] Body text at least 4.5:1; large text (24 px, or 18.66 px bold) at least 3:1.
- [ ] Component edges, meaningful icons and focus rings at least 3:1 against what is next to them.
- [ ] Checked in default, hover, focus, active, visited and selected, and for placeholder text.
- [ ] Text over a picture sits on a scrim, measured at the picture's worst spot.
- [ ] A fix changes lightness only and keeps the hue; report before and after.

## 3. Text and overflow
- [ ] No fixed heights on boxes that hold text; flex and grid children have `min-width: 0`.
- [ ] Headings, card titles, tags and URLs wrap anywhere, so a long string never breaks the layout (script finds cut-off text).
- [ ] Buttons and tags grow with their words and never clip.
- [ ] Line clamping only on a teaser whose full text is one click away.
- [ ] A number stays with its unit and a date stays on one line.
- [ ] Stress content passes: a 120-character title, an unbroken 60-character URL, a one-word title, missing optional fields, eight or more tags.

## 4. Responsive layout
- [ ] Viewport meta `width=device-width, initial-scale=1`; zoom never blocked (script).
- [ ] No sideways scroll at any width (script).
- [ ] Full-height sections use `dvh` or `svh` with a `vh` fallback, and respect safe-area insets.
- [ ] Touch targets at least 44×44 px with 8 px between them (script reports under 24 px as a failure, under 44 px as a note).
- [ ] Every image has width and height or an aspect ratio, and a responsive `srcset` (script finds missing dimensions).
- [ ] An uploaded picture is never cropped against its owner's wishes; where shapes differ, show it whole.

## 5. Light and dark
- [ ] All colours come from semantic tokens; no hard-coded colours in components.
- [ ] The theme is applied before first paint, so the wrong theme never flashes.
- [ ] The visitor's choice is kept; `color-scheme` is set so form controls and scrollbars match.
- [ ] The theme switch is a real button with a name and a state.
- [ ] Every logo, icon, shadow, picture and embed is checked in both themes.

## 6. States
- [ ] Every data-driven or interactive component has default, loading, empty, error, success and partial states.
- [ ] Loading skeletons match the final layout, so nothing shifts.
- [ ] Empty states say why, and offer a next step. Errors say what happened and how to recover, with a retry.
- [ ] Forms: inline checks on blur, an error summary, a busy state while sending, a success message, and a failure that keeps what was typed.
- [ ] Embeds: a facade, a loading state and a fallback card if blocked. Pictures: a placeholder and a broken-image fallback.
- [ ] A custom 404. Content readable with JavaScript off.

## 7. Interaction and motion
- [ ] Hover is an extra, never the only way; every hover style has a matching `:focus-visible` style; hover rules sit inside `@media (hover: hover)`.
- [ ] Hover never shifts layout. Motion never costs the page its layout-shift or responsiveness budget.
- [ ] Reduced motion removes movement and keeps meaning (fades at most). Nothing flashes more than three times a second.
- [ ] Nothing moves for more than five seconds unless the visitor is interacting with it.
- [ ] Cards: one link per card, the whole card clickable, no nested controls fighting it.

## 8. Hierarchy and the first view
- [ ] Only sizes from the type scale; body lines 45 to 75 characters, line height at least 1.5.
- [ ] One icon set, sized to its text, decorative icons hidden from assistive tech.
- [ ] Within five seconds a visitor can tell who this is, what level, and what to do next. One primary action per view.

## 9. Performance (mobile, throttled)
- [ ] Largest paint under 2.5 s, layout shift under 0.1, responsiveness under 200 ms.
- [ ] The largest image loads eagerly with high priority; everything below the fold is lazy.
- [ ] Fonts self-hosted, subset, `font-display: swap` with a size-matched fallback.
- [ ] Video and social embeds load only when asked for.

## 10. The second user: an AI agent acting for a person
- [ ] Real landmarks and one h1, so the page has an outline (script).
- [ ] Controls and links have names made of words, not "click here" or an icon alone.
- [ ] Structured data (JSON-LD) matches what is on the page, never more.
- [ ] Key facts are in text, not only in pictures or on hover.
- [ ] Where it fits, an `/llms.txt` that says what the site is and where things are.
- [ ] Anything an agent might do for the person (book, send, buy) asks the person to confirm, and says so in text.
