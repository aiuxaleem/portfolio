# When a result from ui-check.mjs looks wrong

These come from running the same kind of gate on a real site for weeks.

- **Every view fails with "could not check".** The page did not load: the server is down, the address is wrong, or the machine slept. Open the address in a browser first. On Windows, the System log's Kernel-Power events show standby and restarts.
- **A page passes on the development server and fails on the built site (or the reverse).** Development and production can order stylesheets differently. Run the gate on the production build served locally, the way the host serves it.
- **Dark theme results look the same as light.** The site may set its theme with an attribute instead of the system setting. Pass `--theme-attr=data-theme` (or the site's own attribute name).
- **"Text cut off" on a heading that animates in.** The script runs with reduced motion, so a heading that is still mid-animation means the site animates even under reduced motion. That is a finding of its own.
- **"Text cut off" inside a carousel or a card row.** Only text partly inside a clipping box is reported; text wholly outside it is treated as off-screen content. If a slide's text is reported, the slide is half in view at that width.
- **Targets under 24 px on icon buttons.** Real failures (WCAG 2.5.8) unless the target has 24 px of clear space around it. The script does not measure spacing, so check those by hand before fixing.
- **Lazy images reported without dimensions.** The script scrolls the page once to load them; an image that only loads on a click is not seen.
- **axe and a hidden element.** axe treats only `overflow: hidden` as clipping, not `overflow: clip`; a visually hidden label built with `clip` may be reported. Prefer the standard visually-hidden pattern.
- **The run is slow.** Ten widths, two themes and axe on every view take time. Use `--quick` while working and the full run before calling a page done. Run one gate at a time, with nothing else building.
